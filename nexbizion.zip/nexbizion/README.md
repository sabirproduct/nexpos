readme for deployment
attempt 2
